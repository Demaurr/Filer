from setuptools import setup, find_packages

setup(
    name='Filer',
    version='1.1.2',
    packages=["Filing"],
    author='Demaurr',
    author_email='',
    description='A package for gathering statistics on files in any given Folder and moving them to a specified(given) folder.',
    install_requires=[],
)
